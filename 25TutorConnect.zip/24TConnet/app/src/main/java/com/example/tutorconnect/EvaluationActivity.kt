package com.example.tutorconnect

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tutorconnect.adapters.TutorSessionAdapter
import com.example.tutorconnect.models.SessionStatus
import com.example.tutorconnect.models.TutorRating
import com.example.tutorconnect.models.TutorSession
import com.google.android.material.floatingactionbutton.FloatingActionButton

class EvaluationActivity : AppCompatActivity() {
    private lateinit var adapter: TutorSessionAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyState: LinearLayout

    // Lista temporal de ejemplo con calificaciones
    private val sessions = mutableListOf(
        TutorSession(
            id = "1",
            tutorName = "María González",
            subject = "Ecuaciones Lineales",
            date = "12/03/2024",
            status = SessionStatus.COMPLETED
        ),
        TutorSession(
            id = "2",
            tutorName = "Juan Pérez",
            subject = "Cálculo Diferencial",
            date = "15/03/2024",
            status = SessionStatus.RATED,
            rating = TutorRating(
                sessionId = "2",
                tutorName = "Juan Pérez",
                subject = "Cálculo Diferencial",
                date = "15/03/2024",
                rating = 5,
                feedback = "Excelente explicación de los conceptos difíciles. Muy paciente y claro."
            )
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_evaluation)

        initializeViews()
        setupRecyclerView()
        setupFab()
        updateEmptyState()
    }

    private fun initializeViews() {
        recyclerView = findViewById(R.id.recyclerViewTutors)
        emptyState = findViewById(R.id.emptyState)
    }

    private fun setupRecyclerView() {
        adapter = TutorSessionAdapter(sessions) { session ->
            when (session.status) {
                SessionStatus.COMPLETED -> navigateToRating(session)
                SessionStatus.RATED -> navigateToViewRating(session)
                else -> { /* No action for pending sessions */ }
            }
        }

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun setupFab() {
        findViewById<FloatingActionButton>(R.id.fabAddRating).setOnClickListener {
            startActivity(Intent(this, SelectTutorActivity::class.java))
        }
    }

    private fun navigateToRating(session: TutorSession) {
        val intent = Intent(this, TutorRatingActivity::class.java).apply {
            putExtra("TUTOR_NAME", session.tutorName)
            putExtra("SUBJECT", session.subject)
            putExtra("DATE", session.date)
            putExtra("SESSION_ID", session.id)
            putExtra("SESSION_STATUS", session.status.toString())
        }
        startActivity(intent)
    }

    private fun navigateToViewRating(session: TutorSession) {
        val rating = session.rating
        if (rating != null) {
            val intent = Intent(this, TutorRatingActivity::class.java).apply {
                putExtra("TUTOR_NAME", session.tutorName)
                putExtra("SUBJECT", session.subject)
                putExtra("DATE", session.date)
                putExtra("SESSION_ID", session.id)
                putExtra("SESSION_STATUS", session.status.toString())
                putExtra("RATING", rating.rating)
                putExtra("FEEDBACK", rating.feedback)
            }
            startActivity(intent)
        }
    }

    private fun updateEmptyState() {
        if (sessions.isEmpty()) {
            recyclerView.visibility = View.GONE
            emptyState.visibility = View.VISIBLE
        } else {
            recyclerView.visibility = View.VISIBLE
            emptyState.visibility = View.GONE
        }
    }

    override fun onResume() {
        super.onResume()
        // Aquí se debería actualizar la lista de sesiones desde la base de datos
        adapter.updateSessions(sessions)
        updateEmptyState()
    }
}

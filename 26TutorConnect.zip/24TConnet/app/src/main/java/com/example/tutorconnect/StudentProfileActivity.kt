package com.example.tutorconnect

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StudentProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_profile)

        // Configurar botón de retroceso
        val backButton = findViewById<ImageButton>(R.id.backButton)
        backButton.setOnClickListener {
            finish()
        }

        // TODO: Cargar datos del estudiante
        val nameTextView = findViewById<TextView>(R.id.studentName)
        val emailTextView = findViewById<TextView>(R.id.studentEmail)
        
        // Por ahora usamos datos de prueba
        nameTextView.text = "Nombre del Estudiante"
        emailTextView.text = "estudiante@email.com"
    }
}
